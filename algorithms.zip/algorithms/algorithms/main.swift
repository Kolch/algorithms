//
//  main.swift
//  algorithms
//
//  Created by user on 13.01.2019.
//  Copyright © 2019 Kolchedantsev Alexey. All rights reserved.
//

import Foundation

// Задача 2
func findMax(a:Int,b:Int,c:Int,d:Int) -> Int {
    var r = 0
    if a > b {
        r = a
    } else {
        r = b
    }
    if b >= c {
        r = b
    } else {
        r = c
    }
    if d > r {
        r = d
    }
    return r
}
let x = findMax(a: 31, b: -8, c: 202, d: 32)
print("Наибольшее число - ",x)

// Задача 3
var a = 3
var b = 10

// а - через третью переменную
var c = 3
a = b
b = c
//print(a,b)
// b - без третьей переменной
a = a + b
b = a - b
a = a - b
//print(a,b)

// Задача 4 !!! Без проверки на тип. При вводе символов будет ошибка !
func quadraticEquation(a:Double,b:Double,c:Double) -> String{
    let D:Double = (b*b) - 4*a*c
    if D < 0 {
        let result = "Нет корней"
        return result
    }
    else if D > 0 {
        //Два корня
        let x1 = (-b + sqrt(D))/2*a
        let x2 = (-b - sqrt(D))/2*a
        let result = "Корни уравнения:" + String(x1) + " и " + String(x2)
        return result
    }
    else {
        //Один корень
        let x = -b/2*a
        let result = "Единстенный корень:" + String(x)
        return result
    }
}
print("Введите коэффициенты квадратного уравнения..")
print("A -")
let coefA = readLine()
print("B -")
let coefB = readLine()
print("C -")
let coefC = readLine()
if coefA! != "" && coefB! != "" && coefC! != "" {
let count = quadraticEquation(a: Double(coefA!)!, b: Double(coefB!)!, c: Double(coefC!)!) //Ввод коэф.
print(count)
}
else {
    print("Вы не ввели один из коэффицентов!")
}

// Задача 5
print("Введите номер месяца - ")
let input = readLine()
if input! != "" {
let month = Int(input!)!
    if month > 12 || month < 1{
        print("Нет такого месяца")
    }
    else {
        if month >= 6 && month <= 8 {
            print("Лето")
        }
        if month >= 9 && month <= 11 {
            print("Осень")
        }
        if month >= 3 && month <= 5 {
            print("Весна")
        }
        if month == 1 || month == 2 || month == 12 {
            print("Зима")
        }
    }
}
else {
    print("Вы ввели неправельные данные")
}
// Задача 6
print("Введите свой возраст - ")
let raw_age = readLine()
var str: String
if raw_age! != "" {
    let age = Int(raw_age!)!
    if age >= 1 && age <= 150 {
        let age_end = age % 10
        if age_end == 1 {
            str = "год"
        }
        if age_end >= 2 && age_end <= 4 {
            str = "года"
        }
        else {
            str = "лет"
        }
        print("Вам ", age, str)
    }
    else {
        print("Вы ввели неправельные данные!")
    }
}
else {
    print("Вы ничего не ввели!")
}

//Задача 7 Без проверки на тип !! При вводе буквенных координат будет ошибка!
print("Сравнение полей шахматной доски..")
print("Введите координату X1 -")
var x1 = readLine()
print("Введите координату Y1 -")
var y1 = readLine()
print("Введите координату X2 -")
var x2 = readLine()
print("Введите координату Y2 -")
var y2 = readLine()

var first: Bool
var second: Bool
if x1! != "" && x2! != "" && y1! != "" && y2! != "" {
if Int(x1!)! >= 1 && Int(x1!)! <= 8 && Int(x2!)! >= 1 && Int(x2!)! <= 8 && Int(y1!)! >= 1 && Int(y1!)! <= 8 && Int(y2!)! >= 1 && Int(y2!)! <= 8  {
    if  (Int(x1!)! + Int(y1!)!) % 2 == 0 {
        first = false
    }
    else {
        first = true
    }
    if (Int(x2!)! + Int(y2!)!) % 2 == 0 {
        second = false
    }
    else {
        second = true
    }
    if first == second {
        print("Поля одного цвета")
    }
    else {
        print("Поля разного цвета")
    }
}
else {
    print("Вы ввели неправельные координаты!")
}
}
else {
    print("Вы не ввели одну из координат!")
}

// Задача 8
print("Введите границы интервала..")
print("A - ")
let borderA = readLine()
print("B - ")
let borderB = readLine()

if borderA! != "" && borderB! != "" {
    let bA = Int(borderA!)!
    let bB = Int(borderB!)!
    var i = bA
    while i <= bB {
        print(i,i*i,i*i*i)
        i += 1
    }
}
else {
    print("Вы не ввели одну из границ!")
}

// Задача 9
var n = 468
var k = 29
var l = 0
while n - k >= 0 {
    n = n - k
    l = l + 1
}
print("Частное от деления : ", l)
print("Остаток: ", n)

// Задача 10
n = 77921
var j = 0
var result = false
if n > 0 {
    while n > 0 {
        j = n % 10
        n = n / 10
        if j % 2 != 0 {
            result = true
            break
        }
    }
    print(result)
}
else {
    print("Число < 0, не соответствует условию!")
}

// Задача 11
var t = 0
var summ = 0
while true {
print("Введите число... (Введите 0 чтобы закончить.)")
let number = readLine()
    if number! != "" {
        if Int(number!)! == 0 {
            break
        }
        else {
            if Int(number!)! > 0 && Int(number!)! % 10 == 8 {
summ += Int(number!)!
t += 1
            }
        }
    }
}
if summ != 0 {
print("Среднее арифметическое положительных четных чисел, оканчивающихся на 8 = ", summ / t)
}
else {
    print("Вы не ввели ни одного четного, положительного числа, оканчивающегося на 8!")
}

// Задача 12
func maxOfThree(a:Int,b:Int,c:Int) -> Int {
    var x = 0
    if a > b {
        x = a
    }
    else {
        x = b
    }
    if c > x {
        x = c
    }
    let result = x
    return result
}
let test = maxOfThree(a: -14, b: 41, c: 412)
print("Наибольшее из трех чисел - ", test)

// Задача 13
// от 1 до 100 с использованием функции
var z = 0
while z < 200 {
var random = arc4random()
random = random % 100 + 1
    //print(random)
z += 1
}
// без использования функции
let m = 100
let q = 61
let g = 99
var rand = 42310
var iter = 0
while iter < 100 {
    rand = (q * rand + g) % m
    //print(rand + 1)
    iter += 1
}


// Задача 14

print("Введите число N - ")
let N = readLine()
func getNumberCount(n:Int) -> Int {
    var number = n
    var count = 0
    while number != 0 {
        count += 1
        number = number / 10
    }
    return count
}

if N! != "" {
    let numberN = Int(N!)!
    var k = 1
    while k < numberN {
        let square = k * k
        let length_of_k = getNumberCount(n: k)
        let num_div = Int(pow(10, Double(length_of_k))) // Использовал "pow" - функция возводящая в степень, т.к. оператор "**" в swift не работает.
        let num = square % num_div
        if num == k {
            print(k, "*", k, " = ", k * k)
        }
        k += 1
    }
}
